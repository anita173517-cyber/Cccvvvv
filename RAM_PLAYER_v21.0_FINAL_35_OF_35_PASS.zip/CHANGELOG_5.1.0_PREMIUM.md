# StreamX Media3 Pro 5.1.0-Premium

## Preserved
- Existing dark glass / cyan interface and its layout.
- Existing M3U/Xtream profile, channel, EPG, favorites, recent, search, remote-control, sleep-timer, aspect-ratio, and playback features.

## Updated
- Added a low-cost animated satellite pulse for low-RAM devices; standard devices retain the animated signal rings.
- The startup overlay now waits for Media3's actual `onRenderedFirstFrame()` callback before dismissing on successful video playback.
- Increased the safety fallback to 20 seconds. If video has not appeared, the overlay yields to the app controls and shows a connecting state (or a playlist prompt if no channels are loaded).
- Removed the launch-window background removal that could expose a blank/black SurfaceView during transitions.
- Set a dark Media3 shutter background and enabled keeping content during player reset to reduce visible flashes during stream changes.
- Raised bounded OkHttp dispatcher concurrency to support a modest number of parallel live-stream segment requests.
- Incremented app version to 5.1.0-Premium / versionCode 6.

## Verification status
- XML resources parse successfully.
- Source-level checks for startup behavior passed.
- ZIP archive integrity is checked after packaging.
- A full Android Gradle build and real playback test were not possible in this environment because Android SDK / Gradle build tooling is not installed. Test on target TV hardware before release.
